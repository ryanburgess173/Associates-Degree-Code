<?php
$page_title = "Grocery Store Calculator";
include('main-header.html');
include('globals.php');
include('functions.php');
?>
