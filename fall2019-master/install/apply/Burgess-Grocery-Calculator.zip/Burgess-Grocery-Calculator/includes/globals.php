<?php
$grocery_items = ["Grapes" => 4.00,
    "Bananas" => 3.00,
    "Cucumbers" => 2.00,
    "Carrots" => 2.00];

$choices = array();
?>
